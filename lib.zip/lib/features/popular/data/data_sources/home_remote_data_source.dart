import 'package:dio/dio.dart';
import '../models/movie_model.dart';

class HomeRemoteDataSource {
  final Dio dio = Dio();

  Future<List<MovieModel>> getPopularMovies() async {
    var response = await dio.get("https://jsonfakery.com/movies/paginated");
    List<MovieModel> movies = [];
    for (var item in response.data['data']) {
      movies.add(MovieModel.fromJson(item));
    }
    return movies;
  }

  Future<List<MovieModel>> getNewReleases() async {
    var response = await dio.get("https://jsonfakery.com/movies/paginated");
    List<MovieModel> movies = [];
    for (var item in response.data['data']) {
      movies.add(MovieModel.fromJson(item));
    }
    return movies;
  }
}
