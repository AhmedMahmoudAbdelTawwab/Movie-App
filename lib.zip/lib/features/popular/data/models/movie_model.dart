class MovieModel {
  final dynamic id; // خليناه dynamic عشان يقبل أي نوع ID
  final String? title;
  final String? overview;
  final String? posterPath;
  final double? voteAverage;
  final String? releaseDate;

  MovieModel({
    required this.id,
    required this.title,
    required this.overview,
    required this.posterPath,
    required this.voteAverage,
    required this.releaseDate,
  });

  factory MovieModel.fromJson(Map<String, dynamic> json) {
    return MovieModel(
      id: json['id'], // هيقبله زي ما هو
      title: json['title'] ?? json['name'] ?? "No Title",
      overview:
          json['overview'] ??
          json['description'] ??
          "No description available.",
      posterPath: json['poster_path'] ?? json['image'] ?? "",
      voteAverage: (json['vote_average'] as num?)?.toDouble() ?? 0.0,
      releaseDate: json['release_date'] ?? "N/A",
    );
  }
}
