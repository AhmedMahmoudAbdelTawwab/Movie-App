
import 'package:injectable/injectable.dart';
import 'package:movie_app/features/recomnded/domain/entitie/recommended_entity.dart';
import 'package:movie_app/features/recomnded/domain/repo/data_sourse/recommended_data_source.dart';
import '../api/recommend_api.dart';
import '../model/recommended_dto.dart';

import '../../network/statess.dart';

@Injectable(as: RecommendedDataSource)
class RecommendedDataSourceImp implements RecommendedDataSource {
  final RecommendedApi _recommendedApi;
  RecommendedDataSourceImp(this._recommendedApi);
  @override
  Future<RecommendedEntity> getRecommendedSeries() async {
    final recommendedData = await _recommendedApi.getRecommended();

    if (recommendedData is SuccesApi<RecommendedDto>) {
      final recommendedDto = recommendedData.data!;
      final recommendedEntity = recommendedDto.toEntity();
      return recommendedEntity;
    } else if (recommendedData is ErrorApi<RecommendedDto>) {
      throw Exception(recommendedData.message);
    } else {
      throw Exception("unKnown Error");
    }
  }
}
