import 'package:injectable/injectable.dart';
import 'package:movie_app/features/recomnded/domain/entitie/recommended_entity.dart';
import 'package:movie_app/features/recomnded/domain/repo/data_sourse/recommended_data_source.dart';


import '../../domain/repo/repository/recommended_repository.dart';

@Injectable(as: RecommendedRepository)
class RecommendedRepositoryImp implements RecommendedRepository {
  final RecommendedDataSource _recommendedDataSource;
  RecommendedRepositoryImp(this._recommendedDataSource);
  @override
  Future<RecommendedEntity> getRecommendedSeries() {
    return _recommendedDataSource.getRecommendedSeries();
  }
}
