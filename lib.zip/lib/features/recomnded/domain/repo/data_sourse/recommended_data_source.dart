

import 'package:movie_app/features/recomnded/domain/entitie/recommended_entity.dart';

abstract class RecommendedDataSource {
  Future<RecommendedEntity> getRecommendedSeries();
}
