import 'package:dio/dio.dart';
import 'package:movie_app/core/config/api_config.dart';
import 'package:movie_app/features/search/data/models/movie_model.dart';

abstract class SearchRemoteDataSource {
  Future<List<MovieModel>> searchMovies(String query);
}

class SearchRemoteDataSourceImpl implements SearchRemoteDataSource {
  static const String baseUrl = 'https://api.themoviedb.org/3';

  final Dio _dio;

  SearchRemoteDataSourceImpl([Dio? dio]) : _dio = dio ?? Dio();

  @override
  Future<List<MovieModel>> searchMovies(String query) async {
    final response = await _dio.get(
      '$baseUrl/search/movie',
      queryParameters: {
        'api_key': tmdbApiKey,
        'query': query,
        'language': 'en-US',
        'page': 1,
        'include_adult': false,
      },
    );

    if (response.statusCode == 200 && response.data != null) {
      final results = response.data['results'] as List<dynamic>?;
      if (results == null) {
        return [];
      }
      return results
          .map((json) => MovieModel.fromJson(json as Map<String, dynamic>))
          .toList();
    }

    throw Exception('Failed to search movies');
  }
}
