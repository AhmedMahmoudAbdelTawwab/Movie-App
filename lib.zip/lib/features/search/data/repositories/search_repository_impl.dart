import 'package:movie_app/features/search/data/datasources/search_remote_datasource.dart';
import 'package:movie_app/features/search/domain/entities/movie.dart';
import 'package:movie_app/features/search/domain/repositories/search_repository.dart';

class SearchRepositoryImpl implements SearchRepository {
  final SearchRemoteDataSource remoteDataSource;

  SearchRepositoryImpl({required this.remoteDataSource});

  @override
  Future<List<Movie>> searchMovies(String query) async {
    try {
      final models = await remoteDataSource.searchMovies(query);
      return models.cast<Movie>();
    } catch (e) {
      throw Exception('Failed to search movies: $e');
    }
  }
}
