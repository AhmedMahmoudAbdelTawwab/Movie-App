import 'package:dio/dio.dart';
import 'package:movie_app/features/search/domain/entities/movie.dart';
import 'search_repository.dart';
import '../../data/models/movie_model.dart';

class SearchRepositoryImpl implements SearchRepository {
  final Dio dio;
  final String _apiKey = '9d7f94be913eddf2db40e317d2f12f36';
  final String _baseUrl = 'https://api.themoviedb.org/3/search/movie';

  SearchRepositoryImpl({required this.dio});

  @override
  Future<List<Movie>> searchMovies(String query) async {
    try {
      final response = await dio.get(
        _baseUrl,
        queryParameters: {
          'query': query,
          'api_key': _apiKey,
        },
      );

      if (response.statusCode == 200 && response.data != null) {
        final List results = response.data['results'] ?? [];
        return results.map((e) => MovieModel.fromJson(e)).toList();
      } else {
        throw Exception('Failed to load movies');
      }
    } on DioException catch (e) {
      throw Exception(e.message ?? 'An error occurred during search');
    }
  }
}