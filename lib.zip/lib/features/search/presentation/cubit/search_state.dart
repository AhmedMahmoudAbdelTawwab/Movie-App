import '../../domain/entities/movie.dart';

abstract class SearchState {}

class SearchInitial extends SearchState {}

class SearchLoading extends SearchState {}

class SearchSuccess extends SearchState {
  final List<Movie> movies;
  SearchSuccess({required this.movies});
}

class SearchError extends SearchState {
  final String message;
  SearchError({required this.message});
}