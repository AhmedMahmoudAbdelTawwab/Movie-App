import 'package:hive/hive.dart';
import 'package:movie_app/features/watchlist/data/models/watchlist_movie_model.dart';

abstract class WatchlistLocalDataSource {
  Future<void> addToWatchlist(WatchlistMovieModel movie);
  Future<void> removeFromWatchlist(int movieId);
  Future<List<WatchlistMovieModel>> getWatchlist();
  Future<bool> isMovieInWatchlist(int movieId);
}

class WatchlistLocalDataSourceImpl implements WatchlistLocalDataSource {
  static const String boxName = 'watchlist_box';

  @override
  Future<void> addToWatchlist(WatchlistMovieModel movie) async {
    final box = await _getBox();
    await box.put(movie.id, movie);
  }

  @override
  Future<void> removeFromWatchlist(int movieId) async {
    final box = await _getBox();
    await box.delete(movieId);
  }

  @override
  Future<List<WatchlistMovieModel>> getWatchlist() async {
    final box = await _getBox();
    return box.values.cast<WatchlistMovieModel>().toList();
  }

  @override
  Future<bool> isMovieInWatchlist(int movieId) async {
    final box = await _getBox();
    return box.containsKey(movieId);
  }

  Future<Box<WatchlistMovieModel>> _getBox() async {
    try {
      if (Hive.isBoxOpen(boxName)) {
        return Hive.box<WatchlistMovieModel>(boxName);
      }
      return await Hive.openBox<WatchlistMovieModel>(boxName);
    } catch (e) {
      rethrow;
    }
  }

  Future<Box<WatchlistMovieModel>> _openBox() async {
    try {
      if (Hive.isBoxOpen(boxName)) {
        return Hive.box<WatchlistMovieModel>(boxName);
      }
      return await Hive.openBox<WatchlistMovieModel>(boxName);
    } catch (e) {
      rethrow;
    }
  }
}
