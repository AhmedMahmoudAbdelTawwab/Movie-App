import 'package:hive/hive.dart';
import 'package:movie_app/features/watchlist/domain/entities/watchlist_movie_entity.dart';

part 'watchlist_movie_model.g.dart';

@HiveType(typeId: 0)
class WatchlistMovieModel extends HiveObject {
  @HiveField(0)
  final int id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String overview;

  @HiveField(3)
  final String posterPath;

  @HiveField(4)
  final double voteAverage;

  WatchlistMovieModel({
    required this.id,
    required this.title,
    required this.overview,
    required this.posterPath,
    required this.voteAverage,
  });

  factory WatchlistMovieModel.fromEntity(WatchlistMovieEntity entity) {
    return WatchlistMovieModel(
      id: entity.id,
      title: entity.title,
      overview: entity.overview,
      posterPath: entity.posterPath,
      voteAverage: entity.voteAverage,
    );
  }

  WatchlistMovieEntity toEntity() {
    return WatchlistMovieEntity(
      id: id,
      title: title,
      overview: overview,
      posterPath: posterPath,
      voteAverage: voteAverage,
    );
  }
}
