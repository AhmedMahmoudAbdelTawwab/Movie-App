import 'package:dartz/dartz.dart';
import 'package:movie_app/core/error/failures.dart';
import 'package:movie_app/features/watchlist/data/datasources/watchlist_local_datasource.dart';
import 'package:movie_app/features/watchlist/data/models/watchlist_movie_model.dart';
import 'package:movie_app/features/watchlist/domain/entities/watchlist_movie_entity.dart';
import 'package:movie_app/features/watchlist/domain/repositories/watchlist_repository.dart';

class WatchlistRepositoryImpl implements WatchlistRepository {
  final WatchlistLocalDataSource localDataSource;

  WatchlistRepositoryImpl({required this.localDataSource});

  @override
  Future<Either<Failure, void>> addToWatchlist(
    WatchlistMovieEntity movie,
  ) async {
    try {
      final model = WatchlistMovieModel.fromEntity(movie);
      await localDataSource.addToWatchlist(model);
      return const Right(null);
    } catch (e) {
      return Left(CacheFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> removeFromWatchlist(int movieId) async {
    try {
      await localDataSource.removeFromWatchlist(movieId);
      return const Right(null);
    } catch (e) {
      return Left(CacheFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<WatchlistMovieEntity>>> getWatchlist() async {
    try {
      final movies = await localDataSource.getWatchlist();
      return Right(movies.map((model) => model.toEntity()).toList());
    } catch (e) {
      return Left(CacheFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, bool>> isMovieInWatchlist(int movieId) async {
    try {
      final isInWatchlist = await localDataSource.isMovieInWatchlist(movieId);
      return Right(isInWatchlist);
    } catch (e) {
      return Left(CacheFailure(message: e.toString()));
    }
  }
}
