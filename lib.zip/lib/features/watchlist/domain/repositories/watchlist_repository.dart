import 'package:dartz/dartz.dart';
import 'package:movie_app/core/error/failures.dart';
import 'package:movie_app/features/watchlist/domain/entities/watchlist_movie_entity.dart';

abstract class WatchlistRepository {
  Future<Either<Failure, void>> addToWatchlist(WatchlistMovieEntity movie);
  Future<Either<Failure, void>> removeFromWatchlist(int movieId);
  Future<Either<Failure, List<WatchlistMovieEntity>>> getWatchlist();
  Future<Either<Failure, bool>> isMovieInWatchlist(int movieId);
}
