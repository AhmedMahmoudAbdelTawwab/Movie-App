import 'package:dartz/dartz.dart';
import 'package:movie_app/core/error/failures.dart';
import 'package:movie_app/core/usecase/usecase.dart';
import 'package:movie_app/features/watchlist/domain/entities/watchlist_movie_entity.dart';
import 'package:movie_app/features/watchlist/domain/repositories/watchlist_repository.dart';

class AddToWatchlist implements UseCase<void, WatchlistMovieEntity> {
  final WatchlistRepository repository;

  AddToWatchlist(this.repository);

  @override
  Future<Either<Failure, void>> call(WatchlistMovieEntity params) async {
    return await repository.addToWatchlist(params);
  }
}
