import 'package:dartz/dartz.dart';
import 'package:movie_app/core/error/failures.dart';
import 'package:movie_app/core/usecase/usecase.dart';
import 'package:movie_app/features/watchlist/domain/repositories/watchlist_repository.dart';

class CheckMovieInWatchlist implements UseCase<bool, int> {
  final WatchlistRepository repository;

  CheckMovieInWatchlist(this.repository);

  @override
  Future<Either<Failure, bool>> call(int movieId) async {
    return await repository.isMovieInWatchlist(movieId);
  }
}
