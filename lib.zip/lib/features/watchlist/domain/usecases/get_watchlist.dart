import 'package:dartz/dartz.dart';
import 'package:movie_app/core/error/failures.dart';
import 'package:movie_app/core/usecase/usecase.dart';
import 'package:movie_app/features/watchlist/domain/entities/watchlist_movie_entity.dart';
import 'package:movie_app/features/watchlist/domain/repositories/watchlist_repository.dart';

class GetWatchlist implements UseCase<List<WatchlistMovieEntity>, NoParams> {
  final WatchlistRepository repository;

  GetWatchlist(this.repository);

  @override
  Future<Either<Failure, List<WatchlistMovieEntity>>> call(
    NoParams params,
  ) async {
    return await repository.getWatchlist();
  }
}
