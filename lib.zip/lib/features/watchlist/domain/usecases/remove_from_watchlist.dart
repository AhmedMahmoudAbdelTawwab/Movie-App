import 'package:dartz/dartz.dart';
import 'package:movie_app/core/error/failures.dart';
import 'package:movie_app/core/usecase/usecase.dart';
import 'package:movie_app/features/watchlist/domain/repositories/watchlist_repository.dart';

class RemoveFromWatchlist implements UseCase<void, int> {
  final WatchlistRepository repository;

  RemoveFromWatchlist(this.repository);

  @override
  Future<Either<Failure, void>> call(int movieId) async {
    return await repository.removeFromWatchlist(movieId);
  }
}
