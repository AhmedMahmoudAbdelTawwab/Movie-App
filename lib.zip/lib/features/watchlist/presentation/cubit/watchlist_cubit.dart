import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:movie_app/features/watchlist/domain/entities/watchlist_movie_entity.dart';
import 'package:movie_app/features/watchlist/domain/usecases/add_to_watchlist.dart';
import 'package:movie_app/features/watchlist/domain/usecases/check_movie_in_watchlist.dart';
import 'package:movie_app/features/watchlist/domain/usecases/get_watchlist.dart';
import 'package:movie_app/features/watchlist/domain/usecases/remove_from_watchlist.dart';
import 'package:movie_app/core/usecase/usecase.dart';

part 'watchlist_state.dart';

class WatchlistCubit extends Cubit<WatchlistState> {
  final AddToWatchlist addToWatchlist;
  final RemoveFromWatchlist removeFromWatchlist;
  final GetWatchlist getWatchlist;
  final CheckMovieInWatchlist checkMovieInWatchlist;

  WatchlistCubit({
    required this.addToWatchlist,
    required this.removeFromWatchlist,
    required this.getWatchlist,
    required this.checkMovieInWatchlist,
  }) : super(const WatchlistState());

  Future<void> addMovie(WatchlistMovieEntity movie) async {
    final result = await addToWatchlist(movie);
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (_) => _loadWatchlist(),
    );
  }

  Future<void> removeMovie(int movieId) async {
    final result = await removeFromWatchlist(movieId);
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (_) => _loadWatchlist(),
    );
  }

  Future<void> loadWatchlist() async {
    emit(state.copyWith(isLoading: true));
    _loadWatchlist();
  }

  Future<void> _loadWatchlist() async {
    final result = await getWatchlist(NoParams());
    result.fold(
      (failure) =>
          emit(state.copyWith(isLoading: false, error: failure.message)),
      (movies) =>
          emit(state.copyWith(isLoading: false, movies: movies, error: null)),
    );
  }

  Future<void> checkIfInWatchlist(int movieId) async {
    final result = await checkMovieInWatchlist(movieId);
    result.fold(
      (failure) => emit(state.copyWith(isInWatchlist: false)),
      (isIn) => emit(state.copyWith(isInWatchlist: isIn)),
    );
  }
}
