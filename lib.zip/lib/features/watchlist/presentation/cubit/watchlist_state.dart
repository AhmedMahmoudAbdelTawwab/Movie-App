part of 'watchlist_cubit.dart';

class WatchlistState extends Equatable {
  final List<WatchlistMovieEntity> movies;
  final bool isLoading;
  final String? error;
  final bool isInWatchlist;

  const WatchlistState({
    this.movies = const [],
    this.isLoading = false,
    this.error,
    this.isInWatchlist = false,
  });

  WatchlistState copyWith({
    List<WatchlistMovieEntity>? movies,
    bool? isLoading,
    String? error,
    bool? isInWatchlist,
  }) {
    return WatchlistState(
      movies: movies ?? this.movies,
      isLoading: isLoading ?? this.isLoading,
      error: error,
      isInWatchlist: isInWatchlist ?? this.isInWatchlist,
    );
  }

  @override
  List<Object?> get props => [movies, isLoading, error, isInWatchlist];
}
