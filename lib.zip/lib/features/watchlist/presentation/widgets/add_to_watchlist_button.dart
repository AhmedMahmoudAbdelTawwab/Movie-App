import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:movie_app/features/watchlist/presentation/cubit/watchlist_cubit.dart';
import 'package:movie_app/features/watchlist/domain/entities/watchlist_movie_entity.dart';

class AddToWatchlistButton extends StatelessWidget {
  final WatchlistMovieEntity movie;

  const AddToWatchlistButton({
    Key? key,
    required this.movie,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<WatchlistCubit, WatchlistState>(
      builder: (context, state) {
        return ElevatedButton(
          onPressed: () {
            if (state.isInWatchlist) {
              context.read<WatchlistCubit>().removeMovie(movie.id);
            } else {
              context.read<WatchlistCubit>().addMovie(movie);
            }
          },
          child: Text(
            state.isInWatchlist ? 'Remove from Watchlist' : 'Add to Watchlist',
          ),
        );
      },
    );
  }
}
